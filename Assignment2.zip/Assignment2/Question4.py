#Question 4
#given input list
sample_list=[1,2,3,3,3,3,4,4,5,6]
# function accepting a list as parameter
def my_function(sample_list):
    #Empty list
    unique_list=[]
    # looping with each item in list
    for i in sample_list:
        # checking whether the current item is in unique list or not
        if i not in unique_list:
            # appending each unique value into the unique_list
            unique_list.append(i)
    # returning the resultant list
    return unique_list

print(my_function(sample_list))