#Question 1

Rows=5 #Given number of rows

#outer loop to handle number of rows(0 to Rows)
for i in range(0,Rows):
    #inner loop to handle number of columns
    for j in range(0,i+1):
        #printing stars with a space
        print("*",end=' ')
        #ending line after each row
    print("\r")
#outer loop with decreasing row count(Rows to 0)
for i in range(Rows, 0, -1):
    #inner loop with number of columns
    for j in range(0,i-1):
        print("*",end=' ')
    print("\r")