#Question 2
# Input list
my_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
#loop with range from 0 to length of the list
for i in range(0,len(my_list)):
    # condition to check if the index value is odd or not
    if i%2==1:
        # printing odd index values
        print(my_list[i],end=" ")