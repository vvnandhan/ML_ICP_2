#Question 3
# given input list
x = [23,'Python',23.98]
#empty list
temp=[]
# looping with each element in list
for i in x:
    # appending each element type in to the empty list
    temp.append(type(i))
print(x)
print(temp)