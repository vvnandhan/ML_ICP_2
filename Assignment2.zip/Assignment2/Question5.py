#Question 5
# given input string
input_string='The quick Brow Fox'
# function accepting a string as parameter
def my_function(s):
    upper_case,lower_case=0,0
    # looping with each item in list
    for i in s:
        # checking whether character is a upper case and increasing count
        if(i.isupper()):
            upper_case+=1
        # checking whether character is a lower case and increasing count
        elif(i.islower()):
            lower_case+=1
        else:
            pass
    # printing the desired output by using string formating
    print("No. of Upper-case characters: {0} \nNo. of Lower-case characters: {1}".format(upper_case,lower_case))
# calling the function with input string as parameter
my_function(input_string)